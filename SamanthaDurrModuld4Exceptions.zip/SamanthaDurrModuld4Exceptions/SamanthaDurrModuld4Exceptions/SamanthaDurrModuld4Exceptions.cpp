// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//A class that holds the Custom Exception information.
class SamsCustomException : public std::exception {
public:
    const char* what() const noexcept override
    {
        return "A custom exception has occured.";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    //Throws a standard exception from the logic error.
    throw std::logic_error("A standard exception has occurred.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    //This should never be reached.
    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    //This try will never be hit based on there always being exceptions thrown by
    //the logic. The catch will always appear and give the information needed
    //on what exception was caught.
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cerr << "An exception was caught: " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    //This throws an exception from the custom exception code.
    try
    {
        throw SamsCustomException();
    }
    catch (const SamsCustomException& e)
    {
        std::cerr << "A custom exception was caught: " << e.what() << std::endl;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //Checks that the denominator isn't 0, if it is, then throw a runtime_error.
    if (den == 0)
    {
        throw std::runtime_error("A divide by zero error has occurred.");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    //Test the code with this to check that the result is shown. If the exception is not
    //an exception, it will show the result. If it is, then it will throw an exception.
    //This try segement will never be hit due to an exception always being thrown. Only
    //way to fix this would be to change the denominator.
    try
    {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cerr << "An exception was caught: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const SamsCustomException& e)
    {
        std::cerr << "A custom exception was caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cerr << "An exception was caught in main: " << e.what() << std::endl;
    }
    //This will never be hit because there is no other exception listed within the
    //code.
    catch (...)
    {
        std::cerr << "An unhandled exception was caught in main." << std::endl;
    }
    
    std::cout << "All exception tests are completed." << std::endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu