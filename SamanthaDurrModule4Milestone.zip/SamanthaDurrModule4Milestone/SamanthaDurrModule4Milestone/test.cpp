// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */

TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}


// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    //This asserts that both the base collection is currently empty and has a size of 0 before any entries are added.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    //Adds an entry to collection.
    add_entries(1);

    //This asserts that the collection does contain an item now that an entry has been added. It also makes sure that when
    //checked that it is empty, it is actually false and has something in it.
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    //Adds 5 entries to collection.
    add_entries(5);

    //This checks that the size of the collection is 5, matching the parameter passed in, but also the numbero entries that were
    //previously created.
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanSize)
{
    //Adds 11 entries to collection. This allows for testing whether the max size is greater than up to 10.
    add_entries(11);

    //This is used to check that there were actually 11 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 11);

    //This compares whether the max size of the collection is greater than 0, 1, 5, and 10.
    ASSERT_TRUE(collection->max_size() >= 0);
    ASSERT_TRUE(collection->max_size() >= 1);
    ASSERT_TRUE(collection->max_size() >= 5);
    ASSERT_TRUE(collection->max_size() >= 10);

}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanSize)
{
    //Adds 11 entries to collection. This allows for testing whether the capacity is greater than up to 10.
    add_entries(11);

    //This is used to check that there were actually 11 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 11);

    //This compares whether the capacity of the collection is greater than 0, 1, 5, and 10.
    ASSERT_TRUE(collection->capacity() >= 0);
    ASSERT_TRUE(collection->capacity() >= 1);
    ASSERT_TRUE(collection->capacity() >= 5);
    ASSERT_TRUE(collection->capacity() >= 10);
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    //Adds entries to the collection.
    add_entries(5);

    //This is used to check that there were actually 5 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 5);

    //A constant that contains the initial size of the collection after it was created. This value is not meant to change
    //for the run of the tests.
    const int oldSize = collection->size();

    //Resizes the collection by using the constant of the old size and adding 5 to it.
    collection->resize(oldSize + 5);

    //This constant is to store the information for after the collection has been resized. This is a value that does not change
    //as well for this test. Would possibly need to be changed if this was done more than once for resizing.
    const int newSize = collection->size();

    //This is a comparison assert that checks that the constant variable of newSize is actually larger than the oldSize. This
    //helps to finding out if the system actually did resize itself.
    ASSERT_GT(newSize, oldSize);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    //Adds entries to the collection.
    add_entries(10);

    //This is used to check that there were actually 10 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 10);

    //A constant that contains the initial size of the collection after it was created. This value is not meant to change
    //for the run of the tests.
    const int oldSize = collection->size();

    //Resizes the collection by using the constant of the old size and subtracting 5 to it.
    collection->resize(oldSize - 5);

    //This constant is to store the information for after the collection has been resized. This is a value that does not change
    //as well for this test. Would possibly need to be changed if this was done more than once for resizing.
    const int newSize = collection->size();

    //This checks that the size of newSize is less than the original size that was started with. In this case it should register that
    //there are 5 entries in newSize and 10 in oldSize.
    ASSERT_LT(newSize, oldSize);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeCollectionToZero)
{
    //Adds entries to the collection.
    add_entries(5);

    //This is used to check that there were actually 5 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 5);

    //This tells the system to resize the collection by removing all of the entries through resizing it to 0.
    collection->resize(0);

    //This asserts that the resizing worked and that the collection reads as both having a 0 size and is empty.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesTheCollectionsData)
{
    //Adds entries to the collection.
    add_entries(5);

    //This is used to check that there were actually 5 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 5);

    //Clears the entries added to the collection previously.
    collection->clear();

    //This is asserting that when clear was called, the collection was both emptied and the size was reset to 0.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, ErasesBeginningAndEndErasesTheCollection)
{
    //Adds entries to the collection.
    add_entries(5);

    //This is used to check that there were actually 5 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 5);

    //Erases the collection from beginning to end.
    collection->erase(collection->begin(), collection->end());

    //This is to show that the entire collection was erased when the erase command was called previously. There should be no entries
    //after this and the size is reset to 0 and it registers as empty.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesTheCapacityButNotTheSizeOfTheCollection)
{
    //Adds entries to the collection.
    add_entries(5);

    //This is used to check that there were actually 5 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 5);

    //This assigns the type of data automatically. It then assigns the capacity, which should be 5, to the original capacity for
    //comparing to later.
    auto originalCapacity = collection->capacity();

    //This is saying to reserve the capacity that was programmed into originalCapacity and then reserver another 5 entries.
    collection->reserve(originalCapacity + 5);

    //Checks that the original 5 entries are still there after the reserving.
    ASSERT_EQ(collection->size(), 5);

    //This asserts that the capacity was reserved and that there's the original 5, plus the extra 5 that were reserved earlier.
    ASSERT_EQ(collection->capacity(), originalCapacity + 5);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrowsAnOutOfRangeWhenIndexIsOutOfBounds)
{
    //Adds entries to the collection.
    add_entries(5);

    //This is used to check that there were actually 5 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 5);

    //Asserts that when the at exceeds the amount of entries, there is an out of range error thrown by the system.
    ASSERT_THROW(collection->at(10), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

//This is a positive test that checks that the last entry in the collection can be removed.
TEST_F(CollectionTest, CanRemoveTheLastEntryInTheCollection)
{
    //Adds entries to the collection.
    add_entries(5);

    //This is used to check that there were actually 5 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 5);

    //This removes the last entry in the collection from it.
    collection->pop_back();

    //This asserts that without the entry that is removed, the collection should now read as having a size of 4.
    ASSERT_EQ(collection->size(), 4);

    //This checks that hte last element of the collection is now what was previously the second to last element.
    ASSERT_EQ(collection->back(), *(collection->end() - 1));
}

//This is a negative test that throws an out of range error when an invalid index is being accessed.
TEST_F(CollectionTest, CannotAccessAnInvalidIndexItem)
{
    //Adds entries to the collection.
    add_entries(5);

    //This is used to check that there were actually 5 entries added to the collection. This is so that a potential failure or false
    //positive are avoided otherwise.
    ASSERT_TRUE(collection->size(), 5);

    //This throws an exception when the last 
    ASSERT_THROW(collection->at(-1), std::out_of_range);
}