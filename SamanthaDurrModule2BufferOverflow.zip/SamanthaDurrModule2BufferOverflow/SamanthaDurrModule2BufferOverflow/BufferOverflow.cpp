// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";

  //Checks on the length of the input that has been input into the received value. If the input is within the 20
  //character limit, it will display what was entered and the acount number. Otherwise, the limit has been exceeded
  //and it will inform the user that this is the case.
  if (std::cin.getline(user_input, 20))
  {
	  //If the input does not exceed the maximum length, it will simply display what was entered from the user_input.
	  std::cout << "You entered: " << user_input << std::endl;
  }
  else
  {
	  //If the input does exceed the amount, it will simply display this number.
	  std::cout << "The input length for the characters has been exceeded." << std::endl;
  }

  //This displays the account number as entered in the string when the variable is declared.
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
